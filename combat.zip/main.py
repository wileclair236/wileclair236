from humain import hum
from arme import arme
#les joueur
#          nom /name_text /vie=800 /attack=50
dave=hum("Dave","le joueur Dave",20,)
maya=hum("Maya","la joueuse Maya",140,20)
wil=hum("Wil","le joueur Wil",5000,70000,1000)
#les arme
lance=arme("une lance",150,60)
dague=arme("une dague",50,9)
bâton=arme("un bâton",120,90)
#program
dave.prendre_arme(dague)
wil.prendre_arme(bâton)
wil.dammage(maya)
maya.dammage(dave)




