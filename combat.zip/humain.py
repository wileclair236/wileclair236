class hum :
  def __init__(self,name,name_text,vie=800,attack=50,energie_mana=25,wepon=None,dep_ener_mana=None):
    self.name=name
    self.name_text=name_text
    self.vie=vie
    self.attack=attack
    self.energie_mana=energie_mana
    self.wepon=None
    self.dep_ener_mana = dep_ener_mana
  
  def prendre_arme(self,arme):
    self.arme=arme
    arme=self.arme
    # message que le joueur a pris l'arme
    print("{} a pris {}".format(self.name_text,self.arme.arme_name))
    self.wepon = self.arme.arme_name
    if self.wepon == self.arme.arme_name:
      self.attack+=self.arme.arme_atk
      print("la puissance d'attaque de {} est maintenant de {} points".format(self.name,self.attack))
      print("")
      pass
    
  
    

  def dammage(self,target):
   #sert a faire perde des point de vie à l humain
   self.target=target
   targetatk=self.target.attack
   target_arme_enr=e==
   self.dep_ener_mana =self.arme.ener_mana
   #variable de dammage
   
   if self.target.energie_mana >= 0: 
     # fait dépenser l'énergie/mana du joueur attaquant
     self.target.energie_mana=self.target.energie_mana-self.target.dep_ener_mana
     self.vie-= targetatk

     print(self.name_text)
     print("A perdu {} points de vie".format(targetatk))
     if self.vie > 50 :
        print("il lui reste présentement {} points de vie".format(self.vie))
        pass
     elif self.vie <= 50 and self.vie > 0:
       print("{} a presque plus de vie".format(self.name_text))
       pass
     elif self.vie <= 0:
       print("{} est mort".format(self.name_text))
       print("game over pour {}".format(self.name))
       pass
     print("lui restes {} d'énergie ou de mana".format(self.energie_mana))
     print("")
   else:
    print("{} a plus d'énergie ou de mana".format(self.name_text))