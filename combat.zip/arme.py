class arme:
  def __init__(self,arme_name,arme_atk=50,ener_mana=25):
    self.arme_name=arme_name
    self.arme_atk=arme_atk
    self.ener_mana=ener_mana
  
#class arme_secondaire
































